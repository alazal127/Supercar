<!DOCTYPE HTML>
<html lang=fr>
<head>
<meta charset="utf-8" />
</head>
<body>

<form method="post" action="inserer.php">

Nom: <input type="text" name="name">
<br /><br />
Adresse: <input type="text" name="adresse">
<br /><br />

<input type = "submit" value = "OK">
<input type = "reset" value = "Effacer">

</form>

<br />

<p>
<h1 align='center'>
<a href='signer.php'>Retour au GUESTBOOK </a>
</h1>
</p>

</body>
</html>